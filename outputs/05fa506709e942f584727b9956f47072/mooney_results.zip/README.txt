CompVP Mooney Studio - Batch Results
Created UTC: 2026-10-28T21:56:59.199385+00:00
Successful conversions: 6
Failed or skipped files: 0

Original/ contains uploaded source image files.
Mooney/ contains generated black-and-white PNG images.
manifest.csv records processing settings and measurements.

Processing uses grayscale conversion, optional Gaussian blur,
and binary intensity thresholding. Pixels at or above the
selected threshold become white.

The target white percentage may differ from the actual
percentage when multiple pixels share the same intensity.
Review actual_white_percent in manifest.csv.

The original research paper uses Gaussian filtering and a
16% white-pixel target. Your results should be inspected and
the settings used for your dataset should be reported.
